﻿using System;

namespace FunctionAssignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Zena J. Zahran
			 * Section #01
			 * Function Assignment
			 * 1/28/2016
			*/


			//This is a Navy Sea Cadet Cost Calculator
			//Military funding has been cut
			//Parents are having to stock any supplementary not donated their cadet's seabags
			//In addition to initial membership fees and Summer/ Winter Training

			//prompt the user to enter their cadet's last name
			Console.WriteLine ("Please enter your Cadet's surname?  Once you are done please press return:");

			//Make sure that the user's response has been saved
			string userSurName = Console.ReadLine ();


			//Validate to confirm space has not been left blank
			while (string.IsNullOrWhiteSpace (userSurName)) {

				//Explain to the user what you need them to do (User Directives)
				Console.WriteLine ("We ask that you do not leave any blank spaces in this portal.\r\nSo please type your name and press return:'");

				//Variable must be redefined at this time
				userSurName = Console.ReadLine ();



			}



			//Welcome the User
			Console.WriteLine ("Ahoy! family of Cadet " + userSurName + "...\r\n\r\nWe would like to welcome you to our CSRA Navy Sea Cadet Family!\r\n");

			//prompt the user to enter their name
			Console.WriteLine ("Whom do I have the honor of working with?  Please state you first name:\r\n");

			//Please record response
			string userFirstName = Console.ReadLine ();

			//Validate to confirm space has not been left blank
			while (string.IsNullOrWhiteSpace (userFirstName)) {

				//Explain to the user what you need them to do (User Directives)
				Console.WriteLine ("Grab a cup 'o' Joe, we are just chewing the fat!\r\nYou are in a safe zone.  Please provide your first name and press return:\r\n");

				//Variable must be redefined at this time
				userFirstName = Console.ReadLine ();




			}

			//NSCC Issued Items
			//Fall 2015 - Gender neutral uniforms to be issued
			Console.WriteLine ("After your cadet(s)' probationary period, NSCC will begin to be issue available items for their seasbags.\r\n");



			/*
			 * Standard Greeting
			 * Training information obtained through the official Navy Sea Cadet website
			 * http://www.seacadets.org/nscc
			*/

			//All figures subject to change
			Console.WriteLine ("Let's calculate your initial investment on your cadets!\r\nHow much have you already invested in dress uniforms?");

			//Capture the user response
			string uniformInvoiceString = Console.ReadLine ();

			//Validate users response
			//Create variable to hold the converted value
			decimal uniformExpense;

			while (!decimal.TryParse (uniformInvoiceString, out uniformExpense)) {

				//If a problem arises the loop will run
				//Alert user
				Console.Write ("Maybe we were unclear!  Please type in numbers only...Thank you!\r\nIf nothing has been spent in this category please enter 0, then press enter:");

				//Capture user's response again
				uniformInvoiceString = Console.ReadLine ();


			}


			//How much has been spent on Physical Trainging or PT Gear?
			Console.WriteLine ("How much have you spent on PT Gear to date?\r\nPlease enter zero if you have not purchased any and then, Press return:");

			//Capture user's response
			string ptUniformInvoiceString = Console.ReadLine ();

			//Create variable to catch conversion value
			decimal ptUniformExpense;

			//Validate user's response

			while (!decimal.TryParse (ptUniformInvoiceString, out ptUniformExpense)) {

				//Explain to the user what they have done incorrectly
				Console.WriteLine ("Darn!  Please try again...understand that we must only use numbers in our calculations.\r\nEnter your PT Gear Expenditures and Press enter when done:\r\n");

				//Capture user's response again
				ptUniformInvoiceString = Console.ReadLine ();




			}

			//Blue Digital Uniform Expense (BDU)
			Console.WriteLine ("If you have already purchased your cadet's BDU's, how much have you spent?\r\nIf not purchased at this time, please type zero and Press Return:");

			//Capture user's response
			string bduUniformInvoiceString = Console.ReadLine ();

			//Create variable to catch conversion value
			decimal bduUniformExpense;

			//Validate user's response

			while (!decimal.TryParse (bduUniformInvoiceString, out bduUniformExpense)) {

				//Please explain user error
				Console.WriteLine ("If you have purchased your cadet's Blue Digital Uniform, please enter that expense at this time.\r\nPlease press enter once completed:");

				//Explain what the user has done incorrectly
				Console.WriteLine ("Uh Oh...be careful!  Mistakes may cost you in the long-run.  We would like to issue as much as we can!");

				//Capture user's response again
				bduUniformInvoiceString = Console.ReadLine ();


			}

			//Finally Navy Working Uniform Expenditures (NWU)
			Console.WriteLine ("Finally, have you made any investment towards your cadet's NWU (Olive) working uniform?\r\nIf so, enter that amount and Press Return:");

			//Capture user's response
			string nwuWorkingUniformInvoiceString = Console.ReadLine ();

			//Create variable to catch conversion value
			decimal nwuWorkingUniformExpense;

			//Validate user's response

			while (!decimal.TryParse (nwuWorkingUniformInvoiceString, out nwuWorkingUniformExpense)) {

				//Please explain what user has done incorrectly
				Console.WriteLine ("Sorry...please enter only numeric values! Edit your response with numbers only and Press Return:");

				//Capture user's response again
				nwuWorkingUniformInvoiceString = Console.ReadLine ();


			}


			//Create a function to add expenses to date
			//What is your initial NSCC Investment or what has the user spent so far?


			//Create a variable to catch the returned value
			decimal cadetTotalExpenditureToDate = CadetExpenseTotal (uniformExpense, ptUniformExpense, bduUniformExpense, nwuWorkingUniformExpense);

			Console.WriteLine ("We see that you have spent ${0} to-date.", cadetTotalExpenditureToDate);


			//Create another function



			Console.WriteLine ("All Sea Cadets must attend a mandatory two-week recruit training session.\r\nThese training sessions are taught all-around the country.\r\n\r\nThe curriculum of this training is approved by the U.S. Navy and standardized at all training sites. Cadets receive 106 hours of instruction with a focus on the Navy's core values of honor, courage and commitment.\r\nSo Let's Get Started... \r\n\r\n");


			//NSCC Fee Schedule
			//Create an array
			int[] feeSchedule = new int[3]{ 100, 270, 240 };
			Console.WriteLine (feeSchedule [0]);

			//Create a forloop for Membership and Summer/Winter Training
			foreach (int memberFeeItem in feeSchedule) {

				Console.WriteLine ("NSCC Item Fee - {0}", memberFeeItem);


			}

			//Create a variable for the year fee totals and store sum
			int totalYearFee = 0;

			foreach (int eachInvoice in feeSchedule) {

				//Add total of each yearly membership fee with trainings
				totalYearFee += eachInvoice;


			}

			//Report to the user
			Console.WriteLine ("Your general membership fees along with summer and winter advancement trainings will be around ${0}.\r\n", totalYearFee);




			//Begin Seabag calculation with military sales tax 4.5%
			//Create givens for seabags
			//decimal winterOptionCost = 382m;

			decimal seabagCost = 770m;
			decimal taxRate = .045m;

			//Write function
			//Function call
			//Create a variable to catch the return value

			decimal outcome=totalSeabagCost(seabagCost,taxRate);

			//Report results

			Console.WriteLine ("The total cost of your cadet's seabag for the POLA Boot Camp with be ${0}",outcome);

			//End of Calculations with Sales tax -- All values checked with a calculator and are correct

		

			}

		public static decimal totalSeabagCost(decimal costOfSeabag, decimal tax){

			//Calculate in order to find cost of cadet seabag
			decimal salesTax = costOfSeabag*tax;

			//Add Sales Tax to the cost of the seabag
			decimal totalSeabagCost = costOfSeabag+salesTax;

			return totalSeabagCost;


		}			


		public static decimal CadetExpenseTotal(decimal invoice1, decimal invoice2, decimal invoice3, decimal invoice4){


			//Calculate
			//Create a variable to hold expense sum value
			decimal expenseTotal=invoice1+invoice2+invoice3+invoice4;

			//Return value total to main code
			return expenseTotal;
			
			/*
			 * Initial investment calculated
			 * dress uniform - $50
			 * PT gear - $25
			 * BDU - $75
			 * NWU - $0
			 * total = $150 (checked with calculator
			 * 
			 * NSCC Fees/ Training
			 * Membership - $100
			 * Summer Training - $270
			 * Winter Training - $240
			 * total = $610 (checked with calculator
			 * 
			 * Seabag
			 * Complete Seabag Cost= $770
			 * Sales Tax = 4.5%
			 * Total = $804.65 (check with calculator
			 * 
			 * All values have been checked and are correct
			*/

		}







		}
}