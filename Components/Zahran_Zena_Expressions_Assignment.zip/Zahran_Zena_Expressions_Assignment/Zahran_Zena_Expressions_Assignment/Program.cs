﻿using System;

namespace Zahran_Zena_Expressions_Assignment
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/*
			 * Zena J. Zahran
			 * Section #01
			 * Expressions Assignment
			 * 1/14/2016
			*/

			//Brainstorming an original idea for a calculator 
			//Horse Feed & Supplies cost calculator

			//Welcome instructor and explain what is happening
			Console.WriteLine("Welcome to Zena Zahran's Horse Feed & Supply Cost Calculator! \r\nI am going to calculate how much I spend on horsefeed in six months and a year...  \r\n");
		
			//Prompt the user for basic information


			//How much does horsefeed cost?

			Console.WriteLine ("What is the average price you generally pay for a bag of horsefeed? \r\nPress Return when done!");


			//Listen and record the users response in a variable
			//ReadLine()

			string horsefeedPriceString = Console.ReadLine ();

			//Convert the string variable into a number datatype
			//Remember to use Parse for this conversion
			decimal horsefeedPrice = decimal.Parse(horsefeedPriceString);

			//How many bags do you need to purchase?
			//Prompt user and listen for response
			Console.WriteLine("Wonderful...I can help you with that!!! A 50lb bag of All-Stock costs $"+horsefeedPrice);
			Console.WriteLine("How many bags would you like to purchase on this trip?");

			string horsefeedNumberString = Console.ReadLine ();

			//Convert using Parse...
			int horsefeedNumber = int.Parse(horsefeedNumberString);

			//Provide feedback to user
			Console.WriteLine("Nice!  You would like "+horsefeedNumber+ " bag(s) of All-Stock.  We have that amount in stock!");


			//How frequently are supplies purchased?
			//Prompt response
			Console.WriteLine("How many times do you generally reorder horsefeed in a month?");
			//Capture users response and store in a variable
			string timesPerWeekString = Console.ReadLine();

			//Time to convert
			int timesPerWeek = int.Parse(timesPerWeekString);

			//Calculate how much the user spends per week on horsefeed
			decimal spendsInFeedPerTrip = horsefeedPrice * horsefeedNumber;

			//Calculate how much the user spends per month on horsefeed
			decimal spendsInFeedPerMonth = spendsInFeedPerTrip*timesPerWeek;


			//Calculate how much the user spends per year on average
			decimal spendsInFeedPerYear = spendsInFeedPerMonth*12;

			//Final Horsefeed Output
			Console.WriteLine("You are currently spending $"+spendsInFeedPerTrip+" per trip.");
			Console.WriteLine ("Which means that you spend approximately $"+spendsInFeedPerMonth+" each month.");
			Console.WriteLine ("This means per year, You spend $"+spendsInFeedPerYear+" on horsefeed per year!");

			if (spendsInFeedPerYear > 1000) {
				Console.WriteLine ("Good News!!! Due to your spending habits, you may be eligible for a discount.\r\n");
			}
			Console.WriteLine ("Press enter to continue!");

			//Prompt the using using an array to see if there is any other type of feed that they are wishing to purchase
			//When all calculations are completed make sure that sales tax has been included

			//Create array which will be signified with []
			//datatype[] arrayName = new datatype[size of the array];
			//The size of the array = the number of items which need to be contained 

			string [] equineFeed = new string[5]; 

			//Fill up the array, Declaring the array
			//Index number of array all begin with zero

			equineFeed[0]= "All-Stock";

			equineFeed [1] = ("Hay");

			equineFeed [2] = ("Mineral Salt Blocks");

			equineFeed [3]= ("Alfalfa Cubes ");

			equineFeed [4] = ("Alfalfa Pellets");


			//Capture their response
			equineFeed[4]=Console.ReadLine();

			//Test to make sure that you can see their response
			Console.WriteLine("May I help you with anything else?\r\n"); 

			Console.WriteLine("We currently have specials on the following items in stock:\r\n"+equineFeed[1]+" and "+equineFeed[2]+ " consider some on your next trip!\r\n");


			//Give incentive for the user to come back
			//For every 10 bags of feed puchased you receive a free bag.
			Console.WriteLine ("As a thank you...  On your next puchase of 10 bags you will receive one free.");

			int freeFeed = 10; //value is 10
			freeFeed++;
			Console.WriteLine (freeFeed);
			Console.WriteLine ("That is eleven 50lb bags for the price of 10!");


			/*
			 * Horsefeed (All-Stock) Price = $9.99
			 * # of 50lb bags purchased = 8
			 * Number of trips to feed store = 2
			 * 
			 * The computer generation read as follows
			 * $79.92 per spent on feed per trip
			 * $159.84 is spent per month
			 * $1918.08 on average is spent in a year
			 * 
			 * All numbers have been verified with a calculator and are found to be correct.
			 * 
			*/


	}
	}
	}
